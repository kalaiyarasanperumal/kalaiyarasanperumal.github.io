var users = require("./users");
var recommendation = require("./recommendation");

module.exports = {
	users,
	recommendation,
}